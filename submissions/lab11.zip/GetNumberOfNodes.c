#include <stdio.h>

int GetNumberOfNodes() {
    int num;
    printf("Enter the number of nodes: ");
    scanf("%d", &num);
    return num;
}
